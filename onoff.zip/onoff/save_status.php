<?php
header('Content-Type: application/json');

// Paramètres de connexion à la base de données
$host = 'localhost';
$dbname = 'tpiot';
$username = 'tpiot';
$password = 'tpiot';

try {
    // Connexion à la base de données
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Récupération des données envoyées
    $data = json_decode(file_get_contents('php://input'), true);
    $status = $data['action'];
  //  $date = $data['date'];

    // Préparation et exécution de la requête
    $stmt = $pdo->prepare("INSERT INTO switch (action) VALUES (?)");
    $stmt->execute([$status]);

    // Réponse en cas de succès
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => true, 'message' => 'Status enregistré'], JSON_UNESCAPED_UNICODE);

} catch(PDOException $e) {
    // Réponse en cas d'erreur
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
?> 